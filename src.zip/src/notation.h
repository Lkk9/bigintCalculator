#ifndef NOTATION_H
#define NOTATION_H

typedef enum { REVPOL, INFIX } notation_t;

#endif
